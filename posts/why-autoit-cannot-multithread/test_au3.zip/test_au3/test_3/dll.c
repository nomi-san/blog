#include <stdio.h>
#include <stdarg.h>
#include <windows.h>

DWORD WINAPI test(LPVOID param) {
    MessageBoxA(NULL, "hello", "", 0);
    for (int i = 1; i <= 10; i++) {
        printf("hello, %d\n", i);
        Sleep(100);
        fflush(stdout);
    }
}

extern __declspec(dllexport)
void *get_test() {
    return &test;
}