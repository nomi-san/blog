#include <stdio.h>
#include <windows.h>

typedef DWORD (WINAPI *ThreadProc)(LPVOID lpParam);

static ThreadProc lpFunc = NULL;

extern __declspec(dllexport)
void set_func(ThreadProc lpFn) { // export
	lpFunc = lpFn;
}

extern __declspec(dllexport)
void call_func() { // export
    if (lpFunc != NULL) lpFunc(NULL);
}

static DWORD WINAPI __proc(LPVOID param) {
    call_func();
    return 0;
}

extern __declspec(dllexport)
void start_test() { // export
    HANDLE hThrd = CreateThread(NULL, 0, __proc, NULL, 0, NULL);
    if (hThrd == NULL) MessageBoxW(NULL, L"Lỗi", L"Không thể tạo thread.", 0);
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved) {
	return TRUE;
}