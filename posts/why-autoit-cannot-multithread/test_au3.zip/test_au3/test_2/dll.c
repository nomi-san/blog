#include <stdio.h>
#include <windows.h>

typedef DWORD (WINAPI *ThreadProc)(LPVOID lpParam); 

extern __declspec(dllexport)
DWORD _createThread(ThreadProc lpFunc, LPVOID lpParam, LPDWORD threadId)
{
    return CreateThread(NULL, 0, lpFunc, lpParam, 0, threadId);
}